import sys
from PyQt5 import uic, Qt
import sqlite3
from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap
from PyQt5.QtGui import QPainter, QPen
from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtCore import Qt, QPoint, QLineF
import base64




'''class TableWidget(QTableWidget):
    def __init__(self, parent=None):
        super(TableWidget, self).__init__(parent)
        self.mouse_press = None

    def mousePressEvent(self, event):

        if event.button() == QtCore.LeftButton:
            self.mouse_press = "mouse left press"
        elif event.button() == QtCore.RightButton:
            self.mouse_press = "mouse right press"
        elif event.button() == QtCore.MidButton:
            self.mouse_press = "mouse middle press"
        super(TableWidget, self).mousePressEvent(event)

    def row_column_clicked(self, row, column):
        # print(f'clicked: row={row}, column={column}')
        widget = self.tableWidget.cellWidget(row, 3)
        self.label.setPixmap(widget.pixmap())'''

class Labella(QLabel):

    def __init__(self, parent):
        super().__init__(parent=parent)

        self.setStyleSheet('QFrame')
        self.setGeometry(501, 11, 771, 1021)

        self.lines = []
        self.drawing = False
        self.startPoint = None
        self.endPoint = None
        self.pixelSpacing = 2

    def paintEvent(self, event):
        painter = QPainter(self)

        if self.startPoint and self.endPoint:
            painter.drawLine(self.startPoint, self.endPoint)
            painter.end()

        linePen = QPen(Qt.red, 2.5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)

        for lineData in self.lines:
            line = lineData['points']
            painter.setPen(linePen)
            painter.drawLine(line.p1(), line.p2())
            painter.setPen(Qt.blue)
            painter.drawText((line.p2() + QPoint(0, 10)),
                             '{} mm'.format(lineData['distance']/10))

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            #            self.drawing = True
            #            self.LastPoint = event.pos()
            #
            self.drawing = True
            self.startPoint = event.pos()
            self.update()

    def mouseMoveEvent(self, event):
        if self.startPoint:  # +++
            self.endPoint = event.pos()  # +++
            self.update()

    def mouseReleaseEvent(self, event):
        if self.startPoint and self.endPoint:
            line = QLineF(self.startPoint, self.endPoint)  # !!! QLineF
            self.lines.append({
                'points': line,
                'distance': round(line.length(), 2) * self.pixelSpacing,
            })
            self.startPoint = self.endPoint = None
            self.drawing = False
            self.update()





class App(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('PDDO.ui', self)
        #столбцы таблицы
        self.tableWidget.setColumnWidth(0, 150)
        self.tableWidget.setColumnWidth(1, 150)
        self.tableWidget.setColumnWidth(2, 30)
        self.tableWidget.setHorizontalHeaderLabels(["Name", "View", "Image"])
        self.loaddata()#подключение к бд
        self.le_search.setPlaceholderText("Введите текст...")
        self.dlina.setPlaceholderText("Введите высоту...")
        self.bt_le_search.clicked.connect(self.OnSearch)#поиск по бд
        self.line.clicked.connect(self.pixmap_add)#нужно как-то вынести линии на картинку, а не сам холст
        self.s_rassczet.clicked.connect(self.s_ras)#площадь
        #self.add_button.clicked.connect(self.add_record)
        #self.del_button.clicked.connect(self.del_record)


#--Для линий, не трогать-- ЛИШНЕЕ
        #self.lines = []
        #self.drawing = False
        #self.startPoint = None
        #self.endPoint = None
       # self.pixelSpacing = 2
#--------------------------

        lb = Labella(self)
        self.setGeometry(501, 11, 771, 1021)


    #Подключение к бд
    def loaddata(self, pict=None):
        self.row_count = 1
        #self.table_index = 0
        sqlite_connection = sqlite3.connect('people.db')
        sqlite_connection.text_factory = bytes

        cursor = sqlite_connection.cursor()

        sqlite_select_query = """SELECT * FROM people"""
        cursor.execute(sqlite_select_query)
        records = cursor.fetchall()
        self.tableWidget.verticalHeader().setDefaultSectionSize(100)  # +++

        for i, row in enumerate(records):
            self.tableWidget.setRowCount(self.row_count)
            self.tableWidget.setItem(i, 0, QtWidgets.QTableWidgetItem(str((row[0]), 'utf-8')))
            self.tableWidget.setItem(i, 1, QtWidgets.QTableWidgetItem(str((row[1]), 'utf-8')))
            #self.tableWidget.setItem(i, 2, QtWidgets.QTableWidgetItem(row[2]))

            label_2 = QtWidgets.QLabel()
            label_2.setGeometry(QtCore.QRect(501, 11, 771, 1021))
            self.pix = QPixmap()
            self.pix.loadFromData(row[2])

            _size = QtCore.QSize(771, 1021)
            label_2.setPixmap(self.pix.scaled(_size, QtCore.Qt.KeepAspectRatio))

            #self.tableWidget.setItem(self.table_index, 2, QtWidgets.QTableWidgetItem(row[2]))
            self.tableWidget.setCellWidget(i, 2, label_2)

            #self.table_index += 1
            self.row_count += 1
        cursor.close()
        sqlite_connection.close()
        self.tableWidget.cellClicked.connect(self.row_column_clicked)

    #Показывает, какая была нажатв колонка/столбец
    def row_column_clicked(self, row, column):
        print(f'clicked: row={row}, column={column}')
        widget = self.tableWidget.cellWidget(row, 2)
        self.label_2.setPixmap(widget.pixmap())



   #Открытие изображения по кнопке(выбор файла из проводника) ЛИШНЕЕ
    def pixmap_add(self):
        label_3 = QtWidgets.QLabel()
        fileName, _ = QtWidgets.QFileDialog.getOpenFileName(None, "Select Image", "", "Image Files (*.png *.jpg *.jpeg *.bmp)")
        pixmap = QPixmap(fileName)
        label_3.setGeometry(QtCore.QRect(500, 10, 771, 1021))
        size = QtCore.QSize(771, 1021)
        label_3.setPixmap(pixmap.scaled(size, QtCore.Qt.KeepAspectRatio))


#Поиск в бд
    def OnSearch(self):
        word = self.le_search.text()
        if word:
            for row in range(self.tableWidget.rowCount()):
                match = False
                for cols in range(self.tableWidget.columnCount()):
                    item = self.tableWidget.item(row, cols)
                    if item is not None and item.text() == word:
                        match = True
                        break
                self.tableWidget.setRowHidden(row, not match)
        else:
            for row in range(self.tableWidget.rowCount()):
                self.tableWidget.setRowHidden(row, False)



#Добавление записи в бд
    '''def add_record(self):
        options = QFileDialog.Options()
        options |= QFileDialog.ReadOnly
        file_name, _ = QFileDialog.getOpenFileName(self, "Выберите изображение", "", "Images (*.png *.xpm *.jpg *.bmp *.jpeg)", options=options)
        if file_name:
            self.add_image(file_name)

    def add_image(self, file_name):
        pixmap = QPixmap(file_name)
        if not pixmap.isNull():

            with open(file_name, "rb") as file:
                img_data = file.read()
                img_name = file_name.split("/")[-1]

            Name = "Текст 1 для " + img_name
            View = "Текст 2 для " + img_name

            conn = sqlite3.connect("images.db")
            c = conn.cursor()
            c.execute("INSERT INTO images (image, text1, text2) VALUES (?, ?, ?)", (img_data, Name, View))
            conn.commit()
            conn.close()

            QMessageBox.information(self, "Успех", f"Изображение '{img_name}' успешно добавлено в базу данных!", QMessageBox.Ok)
        else:
            QMessageBox.warning(self, "Ошибка", "Не удалось открыть изображение!", QMessageBox.Ok)'''


    def del_record(self):
        label_4 = QtWidgets.QLabel()

#Удаление записи из бд



#клик по бд (был реализован выше в подключении к бд)
    '''def clickedRowColumn(self, row, cols):
       self.tableWidget = TableWidget()
        print("{}: row={}, column={}".format(self.tableWidget.mouse_press, row, cols))'''



    def s_ras(self):

        l = self.dlina.text()
        print('Dlina=', l)
        s = float(l) + 1
        s1 = s * 0.2646

        print('Dlina=', s1)
        self.ploshad.setText(str(s1))



if __name__ == '__main__':

    app = QApplication(sys.argv)
    ex = App()
    ex.show()

    try:
        sys.exit(app.exec_())
    except SystemExit:
        print('Closing Window...')






